-- This is a placeholder mesh
meshes={{
    vertexes={
        {-1,1},{1,1},{1,-1},{-1,-1}
    },
    colors={
        
    },
    segments={
        {0,1,2,3,0},{0,2},{1,3}
    }
}}
for i = 2, 10 do
    meshes[i] = meshes[1]
    for j = 2, i do
        local x = (j - 2)/10
        local y = -1.1
        if j % 2 == 0 then y = -1.2 end
        table.insert(meshes[i].vertexes, {x, -1})
        table.insert(meshes[i].vertexes, {x, y})
        
        local idx = j + 2
        table.insert(meshes[i].segments, {idx, idx+1})
    end
end